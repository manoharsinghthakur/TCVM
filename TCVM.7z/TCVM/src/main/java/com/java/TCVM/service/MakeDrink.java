package com.java.TCVM.service;

import java.io.IOException;

public interface MakeDrink {
	
	public void makingDrink(int quantity) throws IOException;

}
